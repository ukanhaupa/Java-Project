export interface donorModel{
    name:String,
    phone: String,
    email:String,
    country:String,
    state:String,
    district:String,
    blood_group :String,
}